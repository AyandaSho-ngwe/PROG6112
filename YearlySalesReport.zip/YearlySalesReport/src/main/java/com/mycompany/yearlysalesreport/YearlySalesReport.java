/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.yearlysalesreport;

/**
 *
 * @author Student
 */
public class YearlySalesReport {

    public static void main(String[] args) {
        
        //1D ARRAY FOR THE CITIES
        String[] cities ={"Cape Town","Port Elizabeth","Pretoria"};
        
        //2D array
        int[][] sales = {
            {1000,2000,3000},{2000,3000,4000},{1500,1100,1200}
        };
        
        //Report heading
        System.out.println("--------------------------");
        System.out.println("Gaming Console Report");
        System.out.println("---------------------------");
        System.out.printf("%-18s %-12s %-12s %-12s%n",
                "", "PS5","XBOX","SWITCH");
       
        //CONSOLE SALES FOR EACH MONTH DISPLAYED
        for (int i = 0; i < cities.length;i++) {
            System.out.printf("%-18s %-12d %-12d %-12d%n",
                    cities[i],
                    sales[i][0],
                    sales[i][1],
                    sales[i][2]);           
    }
      //TOTALS DISPLAYED
      System.out.println("\n--------------------------------------");
      System.out.println("CONSOLE SALES TOTALS FOR EACH CITY");
      System.out.println("----------------------------------------");
      
      for (int i = 0; i < cities.length; i++) {
            int total = sales[i][0] + sales[i][1] + sales[i][2];
            
            if (total>= 15) {
                System.out.printf("%-8s %-5d ***%n", cities[i], total);
            } else {
                System.out.printf("%-8s %-5d%n", cities[i], total);
            }
        }
      System.out.println("CITY WITH THE MOST SALES: PORT ELIZABETH");
      System.out.println("---------------------------------------------");
}
}
