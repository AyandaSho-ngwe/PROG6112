/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.consolesalesapplication;

/**
 *
 * @author Student
 */
public class ConsoleSalesApplication extends Console{
    
    //Constructor
    public ConsoleSalesApplication(String consoleType, String store, int totalSales) {
        super(consoleType, store, totalSales);
    }

    
    //Method to print the sales report
    public void printReport() {
        System.out.println("Console Type: " + getConsoleType());
        System.out.println("Store Name: " + getStore());
        System.out.println("Total Sales: " + getTotalSales());
        
    }
    
}

   