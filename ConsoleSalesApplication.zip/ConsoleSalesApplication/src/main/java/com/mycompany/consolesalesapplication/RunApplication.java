/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consolesalesapplication;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class RunApplication {
     public static void main(String[] args) {
         
        //Scanner object
        Scanner input = new Scanner(System.in);
        
        //Displaying the heading
        System.out.println("=============================");
        System.out.println("   CONSOLE SALES SYSTEM   ");
        System.out.println("========================");
        
        //Ask the user to select a console type
        System.out.println("Select Console Type:");
        System.out.println("1.PlayStation");
        System.out.println("2.Xbox");
        System.out.println("3.Nintendo Switch");
        
        System.out.print("Enter your choice: ");
        int choice = input.nextInt();
        
        //Variable to store console type
        String consoleType = null;
        
        //Determine the console type
        switch(choice) {
            case 1:
                consoleType = "PlayStation";
                break;
                
            case 2:
                consoleType = "Xbox";
                break;
                
            case 3:
                consoleType = "Nintendo Switch";
                break;
        }
        input.nextLine();
        
        //Asking for name of store
        System.out.print("Enter store name: ");
        String store = input.nextLine();
        
        //Asking for the total sales
        System.out.print("Enter total amount of sales: ");
        int totalSales = input.nextInt();
        
        //Creating ConsoleSales object
        ConsoleSalesApplication sales = new ConsoleSalesApplication (
                consoleType,
                store,
                totalSales
        );
        
        //Print the report
        System.out.println();
        System.out.println("==============================");
        System.out.println("      SALES REPORT       ");
        System.out.println("==========================");
        
        sales.printReport();
        
        //Closing scanner
        input.close();
        
    }
}

    

