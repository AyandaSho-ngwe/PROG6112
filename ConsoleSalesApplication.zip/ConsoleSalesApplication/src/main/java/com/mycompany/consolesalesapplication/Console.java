/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consolesalesapplication;

/**
 *
 * @author Student
 */
public abstract class Console implements IConsoles {
    
    //Variables to store the console information
    protected String consoleType;
    protected String store;
    protected int totalSales;
    
    //Constructor
    public Console(String consoleType, String store, int totalSales) {
        this.consoleType = consoleType;
        this.store = store;
        this.totalSales = totalSales;
    }
    
    //getter for console type
    @Override
    public String getConsoleType() {
      return consoleType;  
    }
    
    //Getter for store name
    @Override
    public String getStore() {
        return store;
    }
    
    //Getter for total sales
    @Override
    public int getTotalSales() {
        return totalSales;
    }
    
}
